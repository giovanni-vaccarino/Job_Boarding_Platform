# Frontend developed using Vite, React, TS
