export interface IAssetsApi {
  getCvStudent: (studentId: string) => Promise<any>;
}
