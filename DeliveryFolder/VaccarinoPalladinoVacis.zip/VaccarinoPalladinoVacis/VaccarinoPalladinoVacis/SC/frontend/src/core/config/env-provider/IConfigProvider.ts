export interface IConfigProvider {
  for(): Map<string, string>;
}
