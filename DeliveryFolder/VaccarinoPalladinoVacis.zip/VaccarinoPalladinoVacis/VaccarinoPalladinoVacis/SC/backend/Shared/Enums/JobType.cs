﻿namespace backend.Shared.Enums;

public enum JobType
{
    FullTime,
    PartTime
}