﻿namespace backend.Shared.Enums;

public enum JobCategory
{
    Technology,
    Finance,
    Healthcare,
    Education,
    Marketing,
    Sales,
    HumanResources,
    Engineering,
    Legal,
    Operations
}