﻿namespace backend.Shared.Enums;

public enum Rating
{
    OneStar,
    TwoStars,
    ThreeStars,
    FourStars,
    FiveStars
}