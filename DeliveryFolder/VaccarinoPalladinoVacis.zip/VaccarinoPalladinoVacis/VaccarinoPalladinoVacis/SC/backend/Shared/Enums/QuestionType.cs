﻿namespace backend.Shared.Enums;

public enum QuestionType
{
    OpenQuestion,
    MultipleChoice,
    TrueOrFalse,
}