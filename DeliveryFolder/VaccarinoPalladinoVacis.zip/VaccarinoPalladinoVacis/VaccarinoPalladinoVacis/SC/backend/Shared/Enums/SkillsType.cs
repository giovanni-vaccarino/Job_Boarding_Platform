﻿namespace backend.Shared.Enums;

public enum SkillsType
{
    FrontEnd,
    BackEnd,
    FullStack,
    Mobile,
    DevOps,
    DataScience,
    MachineLearning,
    ArtificialIntelligence,
    CyberSecurity,
    CloudComputing,
    BlockChain,
}