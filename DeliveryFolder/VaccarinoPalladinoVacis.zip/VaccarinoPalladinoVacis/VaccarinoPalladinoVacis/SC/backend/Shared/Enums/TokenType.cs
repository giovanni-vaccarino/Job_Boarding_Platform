﻿namespace backend.Shared.Enums;

public enum TokenType
{
    Access,
    Refresh
}