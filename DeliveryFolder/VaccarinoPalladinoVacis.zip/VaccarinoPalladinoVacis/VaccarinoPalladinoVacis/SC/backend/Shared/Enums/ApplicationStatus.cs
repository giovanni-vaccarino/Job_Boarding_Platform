﻿namespace backend.Shared.Enums;

public enum ApplicationStatus
{
    Accepted,
    Rejected,
    Screening,
    OnlineAssessment,
    LastEvaluation,
}