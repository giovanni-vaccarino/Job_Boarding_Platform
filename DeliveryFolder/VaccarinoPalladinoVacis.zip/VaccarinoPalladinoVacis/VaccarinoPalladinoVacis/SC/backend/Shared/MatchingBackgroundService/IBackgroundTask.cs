﻿namespace backend.Shared.MatchingBackgroundService;

public interface IBackgroundTask
{
    Task ExecuteAsync();
}