﻿using Microsoft.AspNetCore.Authorization;

namespace backend.Service.Middlewares.Policies.CompanyPolicy;


public class CompanyAccessRequirement : IAuthorizationRequirement
{
}
