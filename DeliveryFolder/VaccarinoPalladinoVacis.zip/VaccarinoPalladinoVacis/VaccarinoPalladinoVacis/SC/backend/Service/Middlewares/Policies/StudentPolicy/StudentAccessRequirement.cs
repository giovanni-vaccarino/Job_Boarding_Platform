﻿using Microsoft.AspNetCore.Authorization;

namespace backend.Service.Middlewares.Policies.StudentPolicy;

public class StudentAccessRequirement : IAuthorizationRequirement
{
}