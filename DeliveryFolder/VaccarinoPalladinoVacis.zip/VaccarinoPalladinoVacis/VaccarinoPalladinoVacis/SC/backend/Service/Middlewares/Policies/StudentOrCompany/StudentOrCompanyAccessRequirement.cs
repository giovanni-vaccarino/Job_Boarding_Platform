﻿using Microsoft.AspNetCore.Authorization;

namespace backend.Service.Middlewares.Policies.StudentOrCompany;

public class StudentOrCompanyAccessRequirement : IAuthorizationRequirement
{
}